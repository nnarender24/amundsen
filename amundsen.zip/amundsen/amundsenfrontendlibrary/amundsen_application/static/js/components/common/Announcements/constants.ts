export const HEADER_TEXT = 'Announcements';
export const MORE_LINK_TEXT = 'See more';
export const NO_ANNOUNCEMENTS_TEXT = 'No announcements to show';
export const ANNOUNCEMENTS_ERROR_TEXT = 'Could not fetch announcements';
