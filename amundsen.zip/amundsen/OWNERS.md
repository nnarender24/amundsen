* See [CONTRIBUTING.md](CONTRIBUTING.md) for general contribution guidelines.
* See [GOVERNANCE.md](GOVERNANCE.md) for governance guidelines.

This page lists all the maintainers for Amundsen.  This can be used for
routing PRs, questions, etc. to the right place.

# Amundsen committers
- Tao Feng (https://github.com/feng-tao)
- Jin Hyuk Chang (https://github.com/jinhyukchang)
- Tamika Tannis (https://github.com/ttannis)
- Daniel Won (https://github.com/danwom)
- Marcos Iglesias (https://github.com/golodhros)
- Diksha Thakur (https://github.com/dikshathakur3119)
- Allison Suarez Miranda (https://github.com/allisonsuarez)
- Shenghu Yang (https://github.com/shenghuy)
- Mark Grover (https://github.com/markgrover)
- Verdan Mahmood (https://github.com/verdan)
- Bolke de Bruin (https://github.com/bolkedebruin)
- Mariusz Gorski (https://github.com/mgorsk1)
